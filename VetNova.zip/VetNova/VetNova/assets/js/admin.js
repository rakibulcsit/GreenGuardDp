/* ===========================================================
   VetNova - ADMIN PANEL LOGIC
   Only users with role === "admin" can see this page
   (checked by requireAdmin() from vetnova.js).

   The admin can:
     - See how many users have signed up
     - View / remove registered user accounts
     - See a demo list of appointments (static sample data)
=========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const admin = requireAdmin(); // redirects away if not an admin
  if (!admin) return;

  renderUserStats();
  renderUsersTable();
  renderAppointmentsTable();
  setupTabs();
});

/* ---- Top stat cards ---- */
function renderUserStats(){
  const users = getAllUsers();
  document.getElementById("statTotalUsers").textContent = users.length;
  document.getElementById("statTotalAppointments").textContent = sampleAppointments.length;
  document.getElementById("statTotalPets").textContent = "3";     // demo number
  document.getElementById("statTotalVets").textContent = vetsData ? vetsData.length : "6";
}

/* ---- Registered users table ---- */
function renderUsersTable(){
  const users = getAllUsers();
  const tbody = document.getElementById("usersTableBody");

  if (users.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="empty-note">No users have signed up yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = users.map((user, index) => `
    <tr>
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.phone || "-"}</td>
      <td><span class="role-tag user">User</span></td>
      <td><button class="remove-btn" onclick="removeUser(${index})">Remove</button></td>
    </tr>
  `).join("");
}

/* Remove a user account from localStorage (admin action) */
function removeUser(index){
  if (!confirm("Remove this user account? This cannot be undone.")) return;
  const users = getAllUsers();
  users.splice(index, 1);
  saveAllUsers(users);
  renderUsersTable();
  renderUserStats();
}

/* ---- Demo appointments data (static, since there's no backend) ---- */
const sampleAppointments = [
  { owner: "Sanjida Munia", pet: "Tomi", doctor: "Dr. Ayesha Rahman", date: "2026-07-15", time: "10:00 AM" },
  { owner: "Rifat Islam", pet: "Milo", doctor: "Dr. Kamal Hossain", date: "2026-07-16", time: "02:00 PM" },
  { owner: "Nabila Haque", pet: "Bella", doctor: "Dr. Nusrat Jahan", date: "2026-07-18", time: "06:00 PM" }
];

function renderAppointmentsTable(){
  const tbody = document.getElementById("appointmentsTableBody");
  tbody.innerHTML = sampleAppointments.map(a => `
    <tr>
      <td>${a.owner}</td>
      <td>${a.pet}</td>
      <td>${a.doctor}</td>
      <td>${a.date}</td>
      <td>${a.time}</td>
    </tr>
  `).join("");
}

/* ---- Tab switching (Users / Appointments) ---- */
function setupTabs(){
  document.querySelectorAll(".admin-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".admin-tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".admin-panel").forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      document.getElementById(btn.dataset.target).classList.add("active");
    });
  });
}
