/* ===========================================================
   VetNova - BLOG PAGE LOGIC
   Handles the search box and category filter for blog cards.
   (The blog cards themselves are already in blog.html —
   this script just shows/hides them based on the search.)
=========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const searchBtn = document.querySelector(".search-bar button");

  function filterArticles(){
    const keyword = searchInput.value.trim().toLowerCase();
    const category = categoryFilter.value;

    document.querySelectorAll(".blog-card").forEach(card => {
      const title = card.querySelector("h3").textContent.toLowerCase();
      const cardCategory = card.getAttribute("data-category");

      const matchesKeyword = title.includes(keyword);
      const matchesCategory = category === "all" || cardCategory === category;

      card.style.display = (matchesKeyword && matchesCategory) ? "block" : "none";
    });
  }

  if (searchBtn) searchBtn.addEventListener("click", filterArticles);
  if (searchInput) searchInput.addEventListener("keyup", filterArticles);
  if (categoryFilter) categoryFilter.addEventListener("change", filterArticles);
});

/* Simple placeholder for the pagination buttons */
function changePage(pageNumber){
  alert("Loading page " + pageNumber + " (demo only — connect this to real data later).");
}
