

/* ---- 1. NAVBAR HTML ---- */
const navbarHTML = `
<nav class="navbar">
  <div class="nav-container">
    <a href="index.html" class="logo">🐾 Vet<span>Nova</span></a>

    <button class="hamburger" id="hamburgerBtn">☰</button>

    <ul class="nav-links" id="navLinks">
      <li><a href="index.html">Home</a></li>
      <li><a href="about-vn.html">About Us</a></li>
      <li><a href="feature.html">Features</a></li>
      <li><a href="find-vet.html">Find Vet</a></li>
      <li><a href="emergency.html">Emergency Support</a></li>
      <li><a href="blog.html">Pet Care Blog</a></li>
      <li><a href="contact.html">Contact Us</a></li>
    </ul>
<li id="profileNav" style="display:none;">
    <a class="user-profile-nav" href="profile.html">
        <img
            id="navProfilePic"
            src="https://ui-avatars.com/api/?name=User&background=4ecdc4&color=fff"
            alt="Profile">
        <span id="navProfileName">Profile</span>
    </a>
</li>
    <div class="nav-auth" id="navAuth"></div>
  </div>
</nav>`;

/* ---- 2. FOOTER HTML (same on every page) ---- */
const footerHTML = `
<footer class="main-footer">
    <div class="footer-top">
        <div class="footer-container">

            <div class="footer-col col-about">
                <a class="footer-logo" href="index.html">
                    <i class="fas fa-paw"></i> Vet<span>Nova</span>
                </a>

                <p class="footer-brand-desc">
                    Redefining animal welfare and pet care ecosystem in Bangladesh
                    through smart digital solutions.
                </p>

                <div class="footer-socials">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul class="footer-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about-vn.html">About Us</a></li>
                    <li><a href="feature.html">Platform Features</a></li>
                    <li><a href="blog.html">Latest Blogs</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Our Services</h4>
                <ul class="footer-links">
                    <li><a href="find-vet.html">Find Verified Vet</a></li>
                    <li><a href="feature.html#symptom-tracker">Symptom Tracker</a></li>
                    <li><a href="feature.html#blood-bank">Pet Adoption</a></li>
                    <li><a href="feature.html#health-card">Digital Health Card</a></li>
                </ul>
            </div>

            <div class="footer-col col-contact">
                <h4>Official Support</h4>
                <ul class="footer-contact-info">
                    <li><i class="fas fa-map-marker-alt"></i> Dhaka, Bangladesh</li>
                    <li><i class="fas fa-phone-alt"></i> +880 1700-000000</li>
                    <li><i class="fas fa-envelope"></i> support@vetnova.com</li>
                </ul>
            </div>

        </div>
    </div>

    <div class="footer-bottom">
        <div class="footer-container bottom-bar">
            <p>&copy; 2026 VetNova. All Rights Reserved.</p>
            <div class="footer-bottom-links">
                <a href="#">Privacy Policy</a> |
                <a href="#">Terms & Conditions</a>
            </div>
        </div>
    </div>
</footer>
`;

/* ---- 3. Inject navbar & footer as soon as the page loads ---- */
function renderDoctors(doctorsToDisplay) {

    const container = document.getElementById("vets-list-container");
    if (!container) return;

    container.innerHTML = "";

    if (doctorsToDisplay.length === 0) {

        container.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:50px 20px;color:#718096;">
            <i class="fas fa-user-times" style="font-size:3.5rem;color:#cbd5e0;margin-bottom:15px;"></i>
            <h3 style="font-size:1.5rem;margin-bottom:5px;color:#4a5568;">
                No verified vets found in this area.
            </h3>
            <p>
                Try searching with another location like Uttara,
                Dhanmondi, Gulshan, Mirpur, or Bashundhara.
            </p>
        </div>
        `;

        return;
    }

    doctorsToDisplay.forEach(vet => {

        container.innerHTML += `
        <div class="vet-card">

            <div class="vet-badge">Available Today</div>

            <div class="vet-image-area">
                <i class="fas fa-user-md doctor-avatar-icon"></i>
            </div>

            <div class="vet-info">
                <h3>${vet.name}</h3>

                <p class="specialty">${vet.specialty}</p>

                <div class="vet-meta">
                    <span><i class="fas fa-graduation-cap"></i> ${vet.degree}</span>
                    <span><i class="fas fa-star"></i> ${vet.rating}</span>
                    <span><i class="fas fa-map-pin"></i> ${vet.location}</span>
                </div>

                <button class="btn-book-now"
                    onclick="window.location.href='appointment-booking.html?doctor=${encodeURIComponent(vet.name)}'">

                    <i class="far fa-calendar-check"></i>
                    Book Appointment

                </button>
            </div>

        </div>
        `;
    });
}



document.addEventListener("DOMContentLoaded", () => {
  const navPlaceholder = document.getElementById("navbar-placeholder");
  const footerPlaceholder = document.getElementById("footer-placeholder");

  if (navPlaceholder) navPlaceholder.innerHTML = navbarHTML;
  if (footerPlaceholder) footerPlaceholder.innerHTML = footerHTML;

  highlightActiveLink();   // mark current page in the menu
  renderAuthSection();     // show login buttons OR user avatar
  setupHamburgerMenu();    // mobile menu toggle
});

/* ---- 4. Highlight the current page link in the navbar ---- */
function highlightActiveLink(){
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".nav-links a").forEach(link => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
    }
  });
}

/* ---- 5. Mobile hamburger menu toggle ---- */
function setupHamburgerMenu(){
  const btn = document.getElementById("hamburgerBtn");
  const links = document.getElementById("navLinks");
  if (!btn || !links) return;
  btn.addEventListener("click", () => links.classList.toggle("show"));
}

/* ===========================================================
   6. AUTH HELPERS (Login / Signup / Admin / Logout)
=========================================================== */

/* Get the currently logged-in user (or null if nobody is logged in) */
function getCurrentUser(){

    const loggedIn = localStorage.getItem("isLoggedIn");

    if(loggedIn !== "true"){
        return null;
    }

    return JSON.parse(localStorage.getItem("vetnovaUser"));
}

/* Get the list of all registered users (used by signup + admin panel) */
function getAllUsers(){
  const users = localStorage.getItem("vetnova_users");
  return users ? JSON.parse(users) : [];
}

/* Save the full users list back to localStorage */
function saveAllUsers(users){
  localStorage.setItem("vetnova_users", JSON.stringify(users));
}

/* Show the correct navbar section: Login/Signup OR user avatar+menu */
function renderAuthSection() {

    const navAuth = document.getElementById("navAuth");
    if (!navAuth) return;

    const user = getCurrentUser();

    if (user) {

        const profileImage =
            user.profileImage ||
            localStorage.getItem("userProfilePic") ||
            `https://ui-avatars.com/api/?background=12b3a7&color=fff&name=${encodeURIComponent(user.name)}`;

        navAuth.innerHTML = `
        <div class="user-menu" id="userMenu">

            <img class="user-avatar"
                 src="${profileImage}"
                 alt="${user.name}">

            <span class="user-name">
                ${user.name}
                ${user.role === "admin"
                    ? '<span class="admin-badge">ADMIN</span>'
                    : ""}
            </span>

            <div class="dropdown-menu">

                ${
                    user.role === "admin"
                    ? '<a href="admin.html"><i class="fa-solid fa-gauge"></i> Admin Panel</a>'
                    : '<a href="profile.html"><i class="fa-regular fa-user"></i> My Profile</a>'
                }

                <a href="#" onclick="logoutUser();return false;">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    Logout
                </a>

            </div>

        </div>
        `;

        document.getElementById("userMenu").addEventListener("click", function () {
            this.classList.toggle("open");
        });

    } else {

        navAuth.innerHTML = `
            <a href="login.html" class="btn-outline">Login</a>
            <a href="signup.html" class="btn-fill">Sign Up</a>
        `;
    }
}
/* Logout: remove the saved session and reload the page */
function logoutUser(){

    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("vetnovaUser");

    window.location.href = "index.html";
}
/* Helper: pages that REQUIRE login (like Booking, Profile, Admin)
   call this at the top of their <script> to auto-redirect
   visitors who are not logged in. */
function requireLogin(){
  const user = getCurrentUser();
  if (!user) {
    // Remember where the user was trying to go, so login.html
    // can send them back after they log in successfully.
    localStorage.setItem("redirectAfterLogin", window.location.href);
    window.location.href = "login.html";
  }
  return user;
}

/* Helper: pages that require ADMIN role (like admin.html) */
function requireAdmin(){
  const user = requireLogin();
  if (user && user.role !== "admin") {
    alert("Access denied. This page is for admins only.");
    window.location.href = "index.html";
  }
  return user;
}
