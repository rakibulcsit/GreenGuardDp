/* ===========================================================
   VetNova - DIGITAL HEALTH CARD PAGE LOGIC
   Small interactive touch: lets the user preview a new pet
   photo, and the Print/Download buttons show a friendly demo
   message (since there's no backend/server to save files to).
=========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const imageUpload = document.getElementById("imageUpload");
  const petImage = document.getElementById("petImage");

  if (imageUpload && petImage) {
    imageUpload.addEventListener("change", function(){
      const file = this.files[0];
      if (file) petImage.src = URL.createObjectURL(file);
    });
  }

  // Print Card / Download Record buttons
  document.querySelectorAll(".action-buttons .btn").forEach(btn => {
    btn.addEventListener("click", () => {
      if (btn.textContent.includes("Print")) {
        window.print();
      } else {
        alert("Downloading health record... (demo only)");
      }
    });
  });

  // Refill buttons
  document.querySelectorAll(".medication .btn").forEach(btn => {
    btn.addEventListener("click", () => alert("Refill request sent to the pharmacy! 💊"));
  });
});
