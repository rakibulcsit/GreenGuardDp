/* ===========================================================
   VetNova - VACCINE REMINDER PAGE LOGIC
   Handles the "Add Vaccination Record" form (demo only —
   just shows a confirmation, since there is no database).
=========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const saveBtn = document.querySelector(".card .btn");
  if (!saveBtn) return;

  saveBtn.addEventListener("click", () => {
    const petNameInput = document.querySelector('input[placeholder="Pet Name"]');
    const vaccineNameInput = document.querySelector('input[placeholder="Vaccine Name"]');

    if (!petNameInput.value || !vaccineNameInput.value) {
      alert("Please fill in the pet name and vaccine name first.");
      return;
    }

    alert(`✅ Reminder saved for ${petNameInput.value}'s "${vaccineNameInput.value}" vaccine!`);
    petNameInput.value = "";
    vaccineNameInput.value = "";
  });
});
