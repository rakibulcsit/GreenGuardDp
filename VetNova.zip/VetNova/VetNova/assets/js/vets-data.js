
const veterinaryDoctors = [
{
    name: "Dr. Tasnim Ara",
    specialty: "Senior Veterinary Surgeon & Avian Expert",
    type: "Surgeon",
    degree: "DVM (CVASU), MS (Surgery)",
    rating: "4.8 (32 Reviews)",
    location: "Uttara, Dhaka",
    fee: "800",
    image: "https://randomuser.me/api/portraits/women/68.jpg"
},
{
    name: "Dr. M. A. Hannan",
    specialty: "General Veterinary Physician",
    type: "General",
    degree: "DVM, MS (Medicine)",
    rating: "4.9 (61 Reviews)",
    location: "Uttara, Dhaka",
    fee: "700",
  image: "https://randomuser.me/api/portraits/men/32.jpg"
},
{
    name: "Dr. Mahbubul Alam",
    specialty: "General Veterinary Physician",
    type: "General",
    degree: "DVM, PGT (Pet Medicine)",
    rating: "4.7 (19 Reviews)",
    location: "Mirpur, Dhaka",
    fee: "650",
image: "https://randomuser.me/api/portraits/men/45.jpg"
},
{
    name: "Dr. Asif Rahman",
    specialty: "Chief Veterinary Surgeon & Cat Specialist",
    type: "Surgeon",
    degree: "DVM, MS (Surgery)",
    rating: "4.9 (45 Reviews)",
    location: "Dhanmondi, Dhaka",
    fee: "900",
image: "https://randomuser.me/api/portraits/men/52.jpg"
},
{
    name: "Dr. Sabrina Khan",
    specialty: "Senior Veterinary Dental Surgeon",
    type: "Surgeon",
    degree: "DVM, MS (Surgery)",
    rating: "4.9 (54 Reviews)",
    location: "Gulshan, Dhaka",
    fee: "850",
    image: "https://randomuser.me/api/portraits/women/44.jpg"
},
{
    name: "Dr. Kamrul Hasan",
    specialty: "Consultant Veterinary Surgeon",
    type: "Surgeon",
    degree: "DVM, MS (Theriogenology)",
    rating: "4.9 (33 Reviews)",
    location: "Bashundhara, Dhaka",
    fee: "950",
  image: "https://randomuser.me/api/portraits/men/75.jpg"
}
];
function displayVets(vetsList) {
    const container = document.getElementById("vets-list-container");
    if (!container) return;
    
    container.innerHTML = ""; 

    vetsList.forEach(vet => {
        const card = document.createElement("div");
        card.className = "doctor-card";
    card.innerHTML = `


    <div class="doctor-status">
        <i class="fa-solid fa-circle"></i>
        Available Today
    </div>

    <div class="doctor-header">

        <div class="doctor-image">
          <img src="${vet.image}" alt="${vet.name}">
        </div>

        <div class="doctor-details">

            <h3>
                ${vet.name}
                <i class="fa-solid fa-circle-check verify"></i>
            </h3>

            <p class="doctor-speciality">
                ${vet.specialty}
            </p>

            <div class="doctor-degree">
                <i class="fa-solid fa-graduation-cap"></i>
                ${vet.degree}
            </div>

            <div class="doctor-info">

                <span>
                    <i class="fa-solid fa-star"></i>
                    ${vet.rating}
                </span>

                <span>
                    <i class="fa-solid fa-location-dot"></i>
                    ${vet.location}
                </span>

            </div>

        </div>

    </div>

    <div class="doctor-bottom">

        <div class="doctor-fee">
    <span>Consultation Fee</span>
    <h4>${vet.fee}</h4>
    <p>Visit</p>
</div>

        <div class="doctor-btns">


            <button class="book-btn"
            onclick="window.location.href='appointment-booking.html?doctor=${encodeURIComponent(vet.name)}'">

                <i class="fa-regular fa-calendar-check"></i>
                Book Appointment

            </button>

        </div>

    </div>

</div>
`;
        container.appendChild(card);
    });
}

function searchVets() {
    const searchLocation = document.getElementById("location-search-input").value.toLowerCase().trim();
    const selectedSpecialist = document.getElementById("specialist-select").value;

    const filteredVets = veterinaryDoctors.filter(vet => {
        const matchesLocation = vet.location.toLowerCase().includes(searchLocation);
        const matchesSpecialist = (selectedSpecialist === "all") || (vet.type === selectedSpecialist);
        return matchesLocation && matchesSpecialist;
    });

    displayVets(filteredVets);
}


window.addEventListener("DOMContentLoaded", () => {
    const doctorName = new URLSearchParams(window.location.search).get("doctor");

  if (!doctorSelect) {
    displayVets(veterinaryDoctors);
    return;
}

    const doctorSelect = document.getElementById("doctor-select");

    // if doctor dropdown option already exists, select it
    let found = false;

    [...doctorSelect.options].forEach(option => {
        if (option.value === doctorName) {
            option.selected = true;
            found = true;
        }
    });

    // if not found, add new option
    if (!found) {
        const newOption = document.createElement("option");
        newOption.value = doctorName;
        newOption.textContent = doctorName;
        newOption.selected = true;
        doctorSelect.appendChild(newOption);
        doctorSelect.disabled = true;
    }
});

window.onload = function () {
    displayVets(veterinaryDoctors);
};