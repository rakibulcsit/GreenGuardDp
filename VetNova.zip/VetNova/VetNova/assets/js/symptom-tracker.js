/* ===========================================================
   VetNova - SMART SYMPTOM TRACKER LOGIC
   A simple 4-step wizard:
     Step 1: Pet details (type, gender, age, neutered)
     Step 2: Main symptom
     Step 3: A couple of follow-up questions
     Step 4: Final report

   Everything is kept in the "answers" object below.
   IMPORTANT: This tool gives BASIC guidance only.
   It does not replace a real veterinarian.
=========================================================== */

let currentStep = 1;
const totalSteps = 4;

const answers = {
  petType: null,
  gender: null,
  age: null,
  neutered: null,
  symptom: null,
  description: ""
};

/* List of common symptoms shown in Step 2 */
const symptomsList = [
  "Loss of appetite", "Vomiting", "Diarrhea", "Lethargy / Low energy",
  "Coughing or sneezing", "Limping", "Itchy skin / Scratching", "Not urinating normally"
];

document.addEventListener("DOMContentLoaded", () => {
  buildSymptomOptions();
  setupOptionCardClicks();
  updateProgressBar();
});

/* Build the clickable symptom cards for Step 2 */
function buildSymptomOptions(){
  const wrapper = document.getElementById("symptom-selector-container");
  if (!wrapper) return;
  wrapper.innerHTML = symptomsList.map(symptom => `
    <div class="symptom-item" data-value="${symptom}">${symptom}</div>
  `).join("");
}

/* Give every clickable "option-card" / "symptom-item" a click handler
   that marks it as selected and saves the answer */
function setupOptionCardClicks(){
  document.querySelectorAll("#pet-type-grid .option-card").forEach(el =>
    el.addEventListener("click", () => selectOption(el, "#pet-type-grid", "petType"))
  );
  document.querySelectorAll("#pet-gender-grid .option-card").forEach(el =>
    el.addEventListener("click", () => selectOption(el, "#pet-gender-grid", "gender"))
  );
  document.querySelectorAll("#pet-neutered-grid .option-card").forEach(el =>
    el.addEventListener("click", () => selectOption(el, "#pet-neutered-grid", "neutered"))
  );

  document.addEventListener("click", (e) => {
    if (e.target.closest(".symptom-item")) {
      const el = e.target.closest(".symptom-item");
      selectOption(el, "#symptom-selector-container", "symptom", ".symptom-item");
    }
  });

  const ageSelect = document.getElementById("pet-age");
  if (ageSelect) ageSelect.addEventListener("change", (e) => answers.age = e.target.value);

  const descBox = document.getElementById("symptom-description");
  if (descBox) descBox.addEventListener("input", (e) => answers.description = e.target.value);
}

/* Mark one option as "selected" inside its group and store the value */
function selectOption(el, groupSelector, answerKey, itemClass = ".option-card"){
  document.querySelectorAll(`${groupSelector} ${itemClass}`).forEach(item => item.classList.remove("selected"));
  el.classList.add("selected");
  answers[answerKey] = el.getAttribute("data-value");
}

/* Move forward (+1) or backward (-1) through the wizard */
function navigateStep(direction){
  // Simple validation before leaving Step 1 and Step 2
  if (direction === 1 && currentStep === 1 && !answers.petType) {
    alert("Please select your pet type first.");
    return;
  }
  if (direction === 1 && currentStep === 2 && !answers.symptom) {
    alert("Please select the main symptom first.");
    return;
  }

  const nextStep = currentStep + direction;
  if (nextStep < 1 || nextStep > totalSteps) return;

  document.getElementById(`step-${currentStep}`).classList.remove("active");
  document.getElementById(`node-${currentStep}`).classList.remove("active");
  document.getElementById(`node-${currentStep}`).classList.add("completed");

  currentStep = nextStep;

  document.getElementById(`step-${currentStep}`).classList.add("active");
  document.getElementById(`node-${currentStep}`).classList.add("active");

  if (currentStep === 3) buildStep3Questions();
  if (currentStep === 4) buildReport();

  document.getElementById("btn-back").style.display = currentStep === 1 ? "none" : "inline-flex";
  document.getElementById("btn-next").style.display = currentStep === totalSteps ? "none" : "inline-flex";

  updateProgressBar();
  window.scrollTo({ top: document.querySelector(".tracker-container").offsetTop - 30, behavior: "smooth" });
}

/* Fill the progress bar line based on the current step */
function updateProgressBar(){
  const fill = document.getElementById("progress-line-fill");
  if (fill) fill.style.width = `${((currentStep - 1) / (totalSteps - 1)) * 100}%`;
}

/* Step 3: a couple of simple yes/no follow-up questions */
function buildStep3Questions(){
  const wrapper = document.getElementById("dynamic-questions-wrapper");
  wrapper.innerHTML = `
    <div class="form-group">
      <label class="form-label">How long has this been happening?</label>
      <select id="q-duration">
        <option>Less than 24 hours</option>
        <option>1-3 days</option>
        <option>More than 3 days</option>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Is your pet still eating and drinking normally?</label>
      <div class="options-grid" style="grid-template-columns:1fr 1fr;">
        <div class="option-card" data-value="Yes" id="eating-yes">Yes</div>
        <div class="option-card" data-value="No" id="eating-no">No</div>
      </div>
    </div>
  `;
  document.getElementById("eating-yes").addEventListener("click", () => selectEating("Yes"));
  document.getElementById("eating-no").addEventListener("click", () => selectEating("No"));
}
function selectEating(value){
  document.getElementById("eating-yes").classList.toggle("selected", value === "Yes");
  document.getElementById("eating-no").classList.toggle("selected", value === "No");
  answers.eating = value;
}

/* Step 4: put together a simple, friendly summary report.
   NOTE: this is BASIC guidance, not a medical diagnosis. */
function buildReport(){
  document.getElementById("report-pet-meta").textContent = `${answers.petType || "Pet"} • ${answers.gender || "-"}`;

  const durationSelect = document.getElementById("q-duration");
  const duration = durationSelect ? durationSelect.value : "Unknown";

  // Decide an urgency level using a very simple rule-of-thumb
  let urgency = "Low";
  let urgencyColor = "#15803d";
  if (answers.eating === "No" || duration === "More than 3 days") {
    urgency = "Medium";
    urgencyColor = "#a16207";
  }
  const seriousSymptoms = ["Vomiting", "Not urinating normally", "Coughing or sneezing"];
  if (seriousSymptoms.includes(answers.symptom) && answers.eating === "No") {
    urgency = "High";
    urgencyColor = "#b91c1c";
  }

  document.getElementById("report-diagnostics-output").innerHTML = `
    <div class="diagnostic-line"><b>Main Symptom:</b> ${answers.symptom || "-"}</div>
    <div class="diagnostic-line"><b>Duration:</b> ${duration}</div>
    <div class="diagnostic-line"><b>Eating Normally:</b> ${answers.eating || "-"}</div>
    <div class="diagnostic-line"><b>Extra Notes:</b> ${answers.description || "None provided"}</div>
    <div class="diagnostic-line">
      <b>Suggested Urgency:</b>
      <span style="color:${urgencyColor}; font-weight:700;">${urgency}</span>
    </div>
    <p style="margin-top:16px; font-size:13px; color:var(--text-gray);">
      ⚠️ This is a basic, automated suggestion only and is not a medical diagnosis.
      Please <a href="find-vet.html" style="color:var(--primary); font-weight:600;">contact a certified vet</a>
      for proper examination and treatment.
    </p>
  `;
}

/* "Start Over" link at the top of the tracker */
function resetTracker(event){
  event.preventDefault();
  location.reload();
}
