# 🐾 VetNova — Smart Pet Healthcare Website

VetNova is a beginner-friendly, front-end only website for a pet
healthcare platform. It includes a homepage, login/signup with an
**admin panel**, vet finder, appointment booking, adoption listing,
symptom tracker, vaccine reminders, a digital health card, a blog,
and more — all built with plain **HTML, CSS and JavaScript** (no
frameworks, no backend required).

## 🚀 How to run this project

You don't need to install anything!

1. Download / clone this repository.
2. Open the folder in your code editor (VS Code recommended).
3. Right-click `index.html` → **"Open with Live Server"**
   (or just double-click `index.html` to open it in your browser).

That's it — the whole site works locally in your browser.

## 📁 Project Structure

```
VetNova/
├── index.html                 → Homepage
├── login.html                 → Login page (user + admin)
├── signup.html                → Sign up page
├── admin.html                 → Admin dashboard (admin only)
├── about-vn.html               → About Us
├── feature.html                → Features overview
├── find-vet.html               → Search verified vets
├── appointment-booking.html    → Book an appointment (login required)
├── adoption.html                → Pet adoption listing
├── symptom.html                 → Symptom tracker wizard
├── vaccine.html                  → Vaccine reminder dashboard
├── digital-card.html             → Digital pet health record
├── profile.html                   → User's pet profile dashboard (login required)
├── emergency.html                 → Emergency contacts & support
├── blog.html                       → Pet care blog
├── contact.html                     → Contact us form
├── assets/
│   ├── css/     → one CSS file per page + vetnova.css (shared theme)
│   ├── js/      → one JS file per page + vetnova.js (shared logic)
│   └── images/  → put your own images here
```

## 🔑 Login & Admin Access

This is a **front-end only demo**, so there is no real server or
database. User accounts are saved in your browser's `localStorage`.

- **Create a normal account:** go to `signup.html` and fill the form.
- **Login as Admin (built-in demo account):**
  - Email: `admin@vetnova.com`
  - Password: `admin123`

Once logged in as admin, click your name in the navbar → **Admin
Panel** (or go directly to `admin.html`) to see all registered
users and remove accounts, and view a sample list of appointments.

> ⚠️ Because this is a demo, passwords are stored as plain text in
> `localStorage`. **Never do this in a real production app** — a real
> app needs a proper backend with hashed passwords.

## 🎨 Changing the Color Theme

All the site's colors live in ONE place:
`assets/css/vetnova.css` → look for `:root { ... }` at the top.
Change any of these values and the whole website updates:

```css
:root{
  --primary: #12b3a7;   /* main brand teal */
  --primary-dark: #0e9187;
  --secondary: #14c4b3;
  --text-dark: #0e2240;
  --text-gray: #6b7280;
  --bg-light: #f7fbfb;
  --danger: #e74c3c;
}
```

## 🖼️ Changing Images

Every image tag in the HTML has a `📷 IMAGE PLACEHOLDER` comment
right above it. Search for that comment in any file, and replace
the `src="..."` link with your own picture (either another URL, or
a local file you place inside `assets/images/`).

## 🧩 How the Navbar & Footer Work

Instead of copy-pasting the same navbar/footer HTML into every
page, each page just has two empty containers:

```html
<div id="navbar-placeholder"></div>
...
<div id="footer-placeholder"></div>
```

`assets/js/vetnova.js` automatically fills these in when the page
loads. This means if you want to add a new menu link, you only
need to edit it in **one file**: `assets/js/vetnova.js`.

## 🛠️ Built With

- HTML5 & CSS3 (no CSS framework — hand-written, beginner-friendly)
- Vanilla JavaScript (no libraries, no build tools)
- [Font Awesome](https://fontawesome.com/) for icons
- [Google Fonts (Poppins)](https://fonts.google.com/specimen/Poppins)
- `localStorage` for a simple demo login/signup/admin system

## 📌 Notes for Beginners

- Every CSS and JS file has comments explaining what each section
  does — read them if you're learning!
- This project has **no backend**, so anything like "Save",
  "Book Appointment" or "Send Message" only shows a demo alert or
  saves to `localStorage`. To make it fully live, connect it to a
  real backend (Node.js/Express, Firebase, etc.) later.

## 📄 License

Free to use for learning and personal projects.
